# THE BOARD WITHOUT A VICTOR — v0.1

A single-file mobile-friendly world strategy game prototype.

## Files
- `index.html` — the game prototype. Upload this as the GitHub Pages site entry file.

## Publish with GitHub Pages
1. Create a GitHub repository (for example, `the-board-without-a-victor`).
2. Upload `index.html` to the repository's top level (root).
3. Open **Settings → Pages**.
4. Under **Build and deployment**, select **Deploy from a branch**.
5. Select branch **main** and folder **/(root)**, then save.
6. Wait for the Pages URL to appear. Open it on your phone.
7. In Safari on iPhone, tap **Share → Add to Home Screen** to install the web app shortcut.

## Notes
- The game title is English: **THE BOARD WITHOUT A VICTOR**.
- The in-game interface remains Japanese.
- This v0.1 package does not yet include a ZIP-import feature inside the game.
  Automatic ZIP extraction is a required feature for a future file-import workflow.
- This prototype is an early playable UI mockup; some controls/actions are placeholders.
